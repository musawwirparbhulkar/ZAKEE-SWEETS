# ZAKEE Sweets — Site Build

Premium Indian mithai shop website. Static, single-page, no build step.

## Run locally

```bash
# Any static server works. Easiest:
python -m http.server 8000
# then open http://localhost:8000
```

## Files

| Path | What it is |
|---|---|
| `index.html` | The single page. Inline CSS + JS for portability. |
| `assets/img/` | WebP + JPEG fallbacks for every photo, plus the SVG logo. |
| `_headers` | Netlify / Cloudflare Pages security headers (CSP, X-Frame-Options, etc.). |
| `robots.txt` | Crawler directives. |
| `sitemap.xml` | One-page sitemap. |
| `.well-known/security.txt` | Security disclosure contact. |
| `manifest.webmanifest` | PWA install manifest. |

## Security posture

The site is hardened as a static page. In order of impact:

1. **Content-Security-Policy** restricts all script/style/connect sources.
   Only same-origin scripts, Google Maps (for the embed), and Google Fonts
   are allowed. No third-party analytics, ad networks, or trackers.
2. **X-Frame-Options: DENY** + **frame-ancestors 'none'** in CSP —
   clickjacking is blocked.
3. **Strict-Transport-Security** with `preload` (in `_headers`).
4. **Referrer-Policy: strict-origin-when-cross-origin**.
5. **Permissions-Policy** disables every sensor API the site doesn't use.
6. **Honeypot field** in the enquiry form blocks naive spam bots.
7. **Rate-limited submit** (4 s cooldown) on the WhatsApp form opener.
8. **Input sanitization** in JS: length caps, regex on phone, no eval/innerHTML
   for user content, `textContent` for captions.
9. **External links** all carry `rel="noopener noreferrer"`.
10. **Iframe sandbox** on the Google Maps embed.

If you deploy to a platform that doesn't honor `_headers`, replicate the
rules in your reverse-proxy / PaaS config (Cloudflare, Vercel, Netlify,
nginx, Caddy, etc.). The matching meta tags in `index.html` cover cases
where the file isn't honored.

## Updating content

* **Sweets list** — edit the `<article class="product-card">` blocks in
  `index.html`. Each card has the photo path, alt text, name, description,
  and a tag.
* **Phone / address** — search for `+917710910909` and the Google Maps
  short link. Update in the nav, hero, visit, contact, footer, and
  structured data.
* **Photos** — drop new files into `assets/img/`, keep the same naming
  (`<slug>.webp` and `<slug>.jpg`).
* **Logo** — `assets/img/logo.svg` is the source of truth. The PNG is
  generated from it (or a hand-edited replacement) and used as a fallback
  for the favicon.

## Image credits

All product photos are owned by ZAKEE Sweets and sourced from the
@zakee.sweetss Instagram account.
