"""Final image processing for ZAKEE Sweets site.

Strategy:
  - Instagram UI chrome (status bar + comment bar) is stripped.
  - Watermark is left intact — it's the shop's own brand mark and the user
    is sourcing photos from their own @zakee.sweetss handle.  Keeping the
    watermark reinforces brand attribution across the site.
  - All product photos are square-cropped to 1024x1024 (cream letterbox).
  - Team and storefront photos are resized to fixed widths for hero use.
  - Outputs both WebP (preferred) and JPEG fallback.
"""
import os
import cv2
import numpy as np
from PIL import Image, ImageFilter, ImageOps

SRC = r"C:\Users\Admin\OneDrive\Documents\zakee sweet shop"
OUT = r"C:\Users\Admin\.minimax-agent\projects\zakee-sweets\assets\img"
os.makedirs(OUT, exist_ok=True)


def crop_ig_chrome_pil(im, top_frac=0.07, bottom_frac=0.12):
    w, h = im.size
    top = int(h * top_frac)
    bottom = int(h * (1 - bottom_frac))
    return im.crop((0, top, w, bottom))


def fit_square(im, size=1024, bg=(255, 248, 236)):
    w, h = im.size
    scale = size / max(w, h)
    nw, nh = int(w * scale), int(h * scale)
    im = im.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new("RGB", (size, size), bg)
    canvas.paste(im, ((size - nw) // 2, (size - nh) // 2))
    return canvas


def fit_w(im, target_w=1600, target_h=None, bg=(255, 248, 236)):
    w, h = im.size
    nw = target_w
    nh = int(h * (target_w / w))
    im = im.resize((nw, nh), Image.LANCZOS)
    if target_h:
        if nh > target_h:
            top = (nh - target_h) // 2
            im = im.crop((0, top, nw, top + target_h))
        else:
            canvas = Image.new("RGB", (nw, target_h), bg)
            canvas.paste(im, (0, (target_h - nh) // 2))
            im = canvas
    return im


def save_both(im, base, q=85):
    im.save(os.path.join(OUT, f"{base}.webp"), "WEBP", quality=q, method=6)
    im.save(os.path.join(OUT, f"{base}.jpg"), "JPEG", quality=q, optimize=True, progressive=True)


def process_sweet(path, size=1024):
    im = Image.open(path).convert("RGB")
    im = ImageOps.exif_transpose(im)
    im = crop_ig_chrome_pil(im)
    return fit_square(im, size=size)


def process_team(path, target_w=1600):
    im = Image.open(path).convert("RGB")
    im = ImageOps.exif_transpose(im)
    return fit_w(im, target_w=target_w)


def process_storefront(path, target_w=1400, target_h=1610):
    im = Image.open(path).convert("RGB")
    im = ImageOps.exif_transpose(im)
    return fit_w(im, target_w=target_w, target_h=target_h)


def main():
    sweets = [
        ("37888.jpg", "kaju-katli"),
        ("37889.jpg", "motichoor-ladoo"),
        ("img!.jfif", "gulab-jamun"),
        ("37890.jpg", "rasgulla"),
        ("37887.jpg", "royal-barfi"),
        ("37886.jpg", "chocolate-peda"),
    ]
    for src, base in sweets:
        path = os.path.join(SRC, src)
        if not os.path.exists(path):
            print(f"MISSING {path}")
            continue
        sq = process_sweet(path, size=1024)
        save_both(sq, base, q=85)

    save_both(process_storefront(os.path.join(SRC, "37885.jpg")), "storefront", q=85)
    save_both(process_team(os.path.join(SRC, "37883.jpg")), "team", q=85)

    for src, base in [("37891.jpg", "gallery-1")]:
        try:
            sq = process_sweet(os.path.join(SRC, src), size=1024)
            save_both(sq, base, q=82)
        except Exception as e:
            print(f"gallery-1 failed: {e}")

    print("DONE")
    for f in sorted(os.listdir(OUT)):
        if not f.endswith(('.webp', '.jpg', '.png')):
            continue
        size_kb = os.path.getsize(os.path.join(OUT, f)) / 1024
        print(f"  {f:30s}  {size_kb:7.1f} KB")


if __name__ == "__main__":
    main()
